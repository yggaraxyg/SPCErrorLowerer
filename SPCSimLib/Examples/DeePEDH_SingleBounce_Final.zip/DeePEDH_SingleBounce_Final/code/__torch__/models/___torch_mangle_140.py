class Block(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.container.___torch_mangle_124.Sequential
  feat1 : __torch__.torch.nn.modules.container.___torch_mangle_127.Sequential
  feat15 : __torch__.torch.nn.modules.container.___torch_mangle_130.Sequential
  feat2 : __torch__.torch.nn.modules.container.___torch_mangle_133.Sequential
  feat25 : __torch__.torch.nn.modules.container.___torch_mangle_136.Sequential
  feat : __torch__.torch.nn.modules.container.___torch_mangle_139.Sequential
  def forward(self: __torch__.models.___torch_mangle_140.Block,
    argument_1: Tensor) -> Tensor:
    feat = self.feat
    feat25 = self.feat25
    feat2 = self.feat2
    feat15 = self.feat15
    feat1 = self.feat1
    conv1 = self.conv1
    _0 = (conv1).forward(argument_1, )
    _1 = (feat1).forward(_0, )
    _2 = (feat15).forward(_1, )
    _3 = (feat2).forward(_0, )
    _4 = [_1, _2, _3, (feat25).forward(_3, )]
    input = torch.cat(_4, 1)
    _5 = [argument_1, (feat).forward(input, )]
    return torch.cat(_5, 1)
