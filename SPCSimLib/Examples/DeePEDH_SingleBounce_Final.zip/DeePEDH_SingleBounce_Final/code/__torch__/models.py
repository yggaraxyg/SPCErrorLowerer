class DeepBoosting(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  msfeat : __torch__.models.MsFeat
  C1 : __torch__.torch.nn.modules.container.___torch_mangle_11.Sequential
  nl : __torch__.models.NonLocal
  ds1 : __torch__.torch.nn.modules.container.___torch_mangle_18.Sequential
  ds2 : __torch__.torch.nn.modules.container.___torch_mangle_21.Sequential
  ds3 : __torch__.torch.nn.modules.container.___torch_mangle_24.Sequential
  ds4 : __torch__.torch.nn.modules.container.___torch_mangle_27.Sequential
  dfus_block0 : __torch__.models.Block
  dfus_block1 : __torch__.models.___torch_mangle_64.Block
  dfus_block2 : __torch__.models.___torch_mangle_83.Block
  dfus_block3 : __torch__.models.___torch_mangle_102.Block
  dfus_block4 : __torch__.models.___torch_mangle_121.Block
  dfus_block5 : __torch__.models.___torch_mangle_140.Block
  dfus_block6 : __torch__.models.___torch_mangle_159.Block
  dfus_block7 : __torch__.models.___torch_mangle_178.Block
  dfus_block8 : __torch__.models.___torch_mangle_197.Block
  dfus_block9 : __torch__.models.___torch_mangle_216.Block
  convr : __torch__.torch.nn.modules.container.___torch_mangle_223.Sequential
  C2 : __torch__.torch.nn.modules.container.___torch_mangle_226.Sequential
  def forward(self: __torch__.models.DeepBoosting,
    inputs: Tensor) -> Tuple[Tensor, Tensor]:
    C2 = self.C2
    convr = self.convr
    dfus_block9 = self.dfus_block9
    dfus_block8 = self.dfus_block8
    dfus_block7 = self.dfus_block7
    dfus_block6 = self.dfus_block6
    dfus_block5 = self.dfus_block5
    dfus_block4 = self.dfus_block4
    dfus_block3 = self.dfus_block3
    dfus_block2 = self.dfus_block2
    dfus_block1 = self.dfus_block1
    dfus_block0 = self.dfus_block0
    ds4 = self.ds4
    ds3 = self.ds3
    ds2 = self.ds2
    ds1 = self.ds1
    nl = self.nl
    C1 = self.C1
    msfeat = self.msfeat
    _0 = (C1).forward((msfeat).forward(inputs, ), )
    _1 = (ds2).forward((ds1).forward((nl).forward(_0, ), ), )
    _2 = (ds4).forward((ds3).forward(_1, ), )
    _3 = (dfus_block1).forward((dfus_block0).forward(_2, ), )
    _4 = (dfus_block3).forward((dfus_block2).forward(_3, ), )
    _5 = (dfus_block5).forward((dfus_block4).forward(_4, ), )
    _6 = (dfus_block7).forward((dfus_block6).forward(_5, ), )
    _7 = (dfus_block9).forward((dfus_block8).forward(_6, ), )
    _8 = (C2).forward((convr).forward(_7, ), )
    denoise_out = torch.squeeze(_8, 1)
    _9 = torch.to(torch.argmax(denoise_out, -3), 7)
    _10 = torch.div(torch.unsqueeze(_9, 1), CONSTANTS.c0)
    return (_10, denoise_out)
class MsFeat(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.container.Sequential
  conv2 : __torch__.torch.nn.modules.container.___torch_mangle_2.Sequential
  conv3 : __torch__.torch.nn.modules.container.___torch_mangle_5.Sequential
  conv4 : __torch__.torch.nn.modules.container.___torch_mangle_8.Sequential
  def forward(self: __torch__.models.MsFeat,
    inputs: Tensor) -> Tensor:
    conv4 = self.conv4
    conv3 = self.conv3
    conv2 = self.conv2
    conv1 = self.conv1
    _11 = (conv1).forward(inputs, )
    _12 = (conv2).forward(inputs, )
    _13 = [_11, _12, (conv3).forward(_12, ), (conv4).forward(_11, )]
    return torch.cat(_13, 1)
class NonLocal(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  t : __torch__.torch.nn.modules.conv.___torch_mangle_12.Conv3d
  p : __torch__.torch.nn.modules.conv.___torch_mangle_13.Conv3d
  g : __torch__.torch.nn.modules.conv.___torch_mangle_14.Conv3d
  z : __torch__.torch.nn.modules.conv.___torch_mangle_15.Conv3d
  gn : __torch__.torch.nn.modules.normalization.GroupNorm
  def forward(self: __torch__.models.NonLocal,
    argument_1: Tensor) -> Tensor:
    gn = self.gn
    z = self.z
    g = self.g
    p = self.p
    t = self.t
    _14 = (t).forward(argument_1, )
    _15 = (p).forward(argument_1, )
    _16 = (g).forward(argument_1, )
    b = ops.prim.NumToTensor(torch.size(_14, 0))
    _17 = int(b)
    _18 = int(b)
    _19 = int(b)
    _20 = int(b)
    c = ops.prim.NumToTensor(torch.size(_14, 1))
    _21 = int(c)
    d = ops.prim.NumToTensor(torch.size(_14, 2))
    _22 = int(d)
    h = ops.prim.NumToTensor(torch.size(_14, 3))
    _23 = int(h)
    w = ops.prim.NumToTensor(torch.size(_14, 4))
    _24 = int(w)
    _25 = torch.mul(torch.mul(torch.mul(c, d), h), w)
    t0 = torch.view(_14, [_20, 1, int(_25)])
    _26 = torch.mul(torch.mul(torch.mul(c, d), h), w)
    p0 = torch.view(_15, [_19, 1, int(_26)])
    _27 = torch.mul(torch.mul(torch.mul(c, d), h), w)
    g0 = torch.view(_16, [_18, int(_27), 1])
    att = torch.bmm(p0, g0)
    x = torch.bmm(att, t0)
    input = torch.view(x, [_17, _21, _22, _23, _24])
    _28 = (gn).forward((z).forward(input, ), )
    return torch.add(_28, argument_1)
class Block(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.container.___torch_mangle_30.Sequential
  feat1 : __torch__.torch.nn.modules.container.___torch_mangle_33.Sequential
  feat15 : __torch__.torch.nn.modules.container.___torch_mangle_36.Sequential
  feat2 : __torch__.torch.nn.modules.container.___torch_mangle_39.Sequential
  feat25 : __torch__.torch.nn.modules.container.___torch_mangle_42.Sequential
  feat : __torch__.torch.nn.modules.container.___torch_mangle_45.Sequential
  def forward(self: __torch__.models.Block,
    argument_1: Tensor) -> Tensor:
    feat = self.feat
    feat25 = self.feat25
    feat2 = self.feat2
    feat15 = self.feat15
    feat1 = self.feat1
    conv1 = self.conv1
    _29 = (conv1).forward(argument_1, )
    _30 = (feat1).forward(_29, )
    _31 = (feat15).forward(_30, )
    _32 = (feat2).forward(_29, )
    _33 = [_30, _31, _32, (feat25).forward(_32, )]
    input = torch.cat(_33, 1)
    _34 = [argument_1, (feat).forward(input, )]
    return torch.cat(_34, 1)
